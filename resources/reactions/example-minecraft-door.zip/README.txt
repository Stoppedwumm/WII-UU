A WII-UU reactions pack: put this .zip in ~/.wiiuu/reactions (or use the editor's
"Send to WII-UU"), and the videos show up as the Reactions channel on WII-UU's home screen.
The captions/ are standard WebVTT subtitles for any player.
