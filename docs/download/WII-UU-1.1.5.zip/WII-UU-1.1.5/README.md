# WII-UU

A Wii U Menu–style emulator frontend written in Java, with a built-in web server that turns
any phone into a Wii U–like GamePad. There are no dependencies beyond Java 17+.

Website: **https://wiiuu.stoppedwumm.net** (served from `docs/`). It has a one-line install for
Linux, Raspberry Pi and macOS: `curl -fsSL https://wiiuu.stoppedwumm.net/get.sh | bash`.

![Menu](docs/menu.png)
![TV and phone GamePad](docs/tv-and-gamepad.jpg)

It covers consoles from the NES to the Wii U and Switch, and Sony up to the PS4:

| Nintendo | Sega | Sony |
|---|---|---|
| NES, SNES, Game Boy/Color, N64, GBA, GameCube, DS, Wii, 3DS, **Wii U**, **Switch** | Master System, Genesis/Mega Drive, Saturn, Dreamcast | PS1, PS2, PSP, PS3, **PS4** |

WII-UU is a **launcher**: it finds your games, shows them in the Wii U–style UI and starts
the right emulator for each one. Each emulator (Mesen, Snes9x, Mupen64Plus, Dolphin, Cemu,
Ryujinx, DuckStation, PCSX2, PPSSPP, RPCS3, shadPS4 …) is installed separately. You also need
your own legally dumped games and, where an emulator requires it, your own firmware or keys.

## Install

Download `WII-UU-1.0.0.zip`, unzip it, then:

* **Linux / macOS:** `./install.sh`
  (on Linux, `./install.sh --with-emulators` also installs the emulators, from official releases or source, and
  configures them for you; see below.)
* **Windows:** double-click `install.bat`

The installer:

* checks for Java 17+ and offers to install it (apt, dnf, pacman, zypper, Homebrew or winget)
* installs the app and adds a `wiiuu` command plus a menu, Start-menu or Desktop shortcut
* creates `~/WiiUU/roms/<system>` folders
* on Windows it adds a firewall rule when run as administrator; on Linux it prints the `ufw` or
  `firewalld` command to run

To uninstall, run `./install.sh --uninstall` or `install.ps1 -Uninstall`. Your ROMs and settings are kept.

## Installing emulators (Linux, Raspberry Pi)

`emulators.sh` (installed as `wiiuu-emulators`) sets up the emulators and points WII-UU's system
commands at them. It doesn't use Flatpak or containers.

* **Official releases first:** for each emulator it downloads the newest prebuilt Linux release
  for your CPU (x86-64 or 64-bit ARM such as a Raspberry Pi 4/5) from the project's GitHub or
  GitLab releases. The right file is chosen by name at install time, so new versions are picked
  up automatically. AppImages are unpacked, so they run without FUSE.
* **Source as fallback:** if a project publishes no Linux build for your CPU (for example
  Dolphin, or most ARM builds), the script compiles its latest source instead.

```sh
wiiuu-emulators              # releases where available; builds the light rest from source
wiiuu-emulators --all        # also build heavy emulators that have no release (e.g. Dolphin)
wiiuu-emulators --only ppsspp,duckstation
wiiuu-emulators --update     # update everything installed; skips what is already newest
wiiuu-emulators --list       # what is available / installed on this machine
wiiuu-emulators --nightly    # allow pre-release / rolling builds
wiiuu-emulators --source     # always build from source (bleeding edge)
wiiuu-emulators --releases-only
```

* **Emulators:**
  * With official releases: DuckStation, RPCS3, Ryujinx, Cemu, Azahar, melonDS, PPSSPP, Flycast,
    mGBA, Snes9x, FCEUX, and on x86-64 also PCSX2 and shadPS4. Whether an ARM64 build exists is
    up to each project.
  * Always built from source: Mupen64Plus, Mednafen and Dolphin, which publish no Linux binaries.
* **Build details:** source builds install their apt dependencies only when needed, and pick the
  number of parallel jobs from your RAM. Heavy builds can take hours on a Pi and need about 4 GB
  of swap on boards with under 6 GB of RAM.
* **Logs and files:** logs go to `~/.wiiuu/logs/build/<name>.log`. Emulators are kept in
  `~/.local/share/wiiuu-emulators`, and uninstalling WII-UU keeps them.
* **Rate limit:** GitHub allows 60 anonymous API requests per hour. Set `GITHUB_TOKEN` if you hit it.
* **Not supported:** PCSX2 (PS2) and shadPS4 (PS4) only run on x86-64.

## Use

1. Copy games into `~/WiiUU/roms/<system>/`. The folder names are `nes snes gb n64 gba gc nds wii 3ds wiiu
   switch sms genesis saturn dc ps1 ps2 psp ps3 ps4`.
   * PS3 and PS4 games are folders. WII-UU finds the `EBOOT.BIN`/`eboot.bin` inside each one.
   * Wii U: `.wua`, `.wud`, `.wux`, or the `code/*.rpx` of an unpacked game.
   * Covers: put `covers/<game name>.png` (or `.jpg`) in a system folder, or place the image next to the ROM
     with the same name. PS3 `ICON0.PNG` and PS4 `sce_sys/icon0.png` are used automatically.
2. Start WII-UU and press **F1** (Settings). Check each system's emulator command, or use
   *Emulator program…* to pick the executable. In a command, `{rom}` is the game file, `{dir}`
   is its folder and `{name}` is its title.
3. Choose a system, then a game, and press Enter or A.

| Keyboard | GamePad | Action |
|---|---|---|
| Arrows / WASD | D-pad / left stick | Move |
| Enter / Space | A | Open / play |
| Esc / Backspace | B | Back |
| PgUp / PgDn, Q / E | L / R, ZL / ZR | Change page |
| F2 | + | Show the GamePad QR code |
| F5 | − | Rescan games |
| F1 | – | Settings |
| F11 | – | Toggle fullscreen |
| Ctrl+Q | HOME → Close game | Quit the running game |

## Phone as GamePad

Press **+** or **F2** on the TV and scan the QR code. You can also open the URL shown there on a phone
connected to the same Wi-Fi and enter the 4-digit pairing code.

The page is laid out like a Wii U GamePad. It has two analog sticks (tap a stick for L3 or R3),
a D-pad with diagonals, ABXY, L/R/ZL/ZR, −, HOME and +. You can slide a finger from one button
to another. It vibrates on each press, keeps the screen awake, and can go fullscreen or be added
to the home screen.

The GamePad's screen shows your library, and tapping a game starts it on the TV. While a game
runs, it shows *Now Playing*, and HOME opens a menu with *Close game*. Up to 4 phones can connect,
and each one is assigned a player number (P1–P4).

**Phones stay paired.** The pairing code is created once and kept, and every paired phone keeps
its player number in `~/.wiiuu/pads.properties`. When WII-UU restarts, phones reconnect on their
own. To unpair all phones, change the code under *Settings → General*.

### How input reaches emulators

* **Linux (including Raspberry Pi): real controllers.** Each phone becomes a virtual **Xbox 360
  controller** through the kernel's `uinput`. Emulators detect it like a USB pad, with analog
  sticks, analog triggers and all buttons, and it works whichever window has focus. Buttons are
  mapped by position (Nintendo A = right, B = bottom). `install.sh` enables this: it loads
  `uinput` and adds a udev rule. It needs `python3`.
* **Fallback: keyboard keys (macOS, Windows).** Without virtual controllers, WII-UU types keys
  into the focused emulator window.
  * **Player 1:** gets each emulator's own default keyboard layout, so nothing needs mapping for
    Dolphin (GameCube), PPSSPP, mGBA, melonDS, DuckStation, Ryujinx and Azahar.
  * **Other emulators and players 2–4:** use the layout under *Settings → GamePad Keys*, which
    follows RetroArch. Keys you set there always win.
  * **Adjusting one emulator's layout:** use `keys.<emulator>.<BUTTON>=KEY`, for example
    `keys.dolphin.ZL=A`.
  * `input.keys=on` forces keys even when virtual controllers work.

| Button | P1 key | P2 key |
|---|---|---|
| D-pad | Arrow keys | 8 / 5 / 4 / 6 |
| A B X Y | X Z S A | 3 2 9 1 |
| L R ZL ZR | Q W E R | 7 0 O P |
| + / − | Enter / Shift | N / M |
| Left stick | T F G H | 8 5 4 6 |
| Right stick | I J K L | – |
| L3 / R3 | C / V | B / Y |

Notes on the keyboard fallback:

* **Linux Wayland:** keys reach X11/XWayland windows. Most emulators accept them, and Qt apps
  can be forced with `QT_QPA_PLATFORM=xcb`.
* **macOS:** allow Java under *Privacy & Security → Accessibility*.

## The GamePad screen: Wii U, DS and 3DS

As on a real Wii U, the phone's screen shows a picture from the PC and you can touch it.

![Phone GamePad showing the Wii U GamePad screen](docs/gamepad.png)
The picture is streamed at 30 fps.

* **Linux and Windows:** with **ffmpeg** installed (the installers offer it), capture and encoding
  are fast enough for a Raspberry Pi.
* **macOS:** uses **ScreenCaptureKit** through a small Swift helper (`resources/mac/capture.swift`).
  The GPU crops and scales the picture, and macOS encodes it. WII-UU compiles the helper itself
  on first start with the Xcode Command Line Tools (`xcode-select --install`; Homebrew already
  installs them). Until the helper is ready, or if it fails, slower Java capture is used. It needs
  *Screen Recording* (see macOS setup). If something fails, the reason is in
  `~/.wiiuu/logs/capture.log`.
* **TV mode during a game** streams only the emulator's window, not the whole desktop.
  `stream.tvFollowsGame=false` mirrors the whole screen instead.
* **If ffmpeg fails:** WII-UU switches to Java capture on its own.
* **On the phone:** only the newest frame is drawn, so a slow phone drops frames instead of
  falling behind.

* **GamePad / Touch screen:** when a game with a second screen starts, the phone switches to it
  automatically, and a tap becomes a mouse click at that spot. Emulators read those clicks as
  touch input.
  * **Wii U (Cemu):** turn on *View → Separate GamePad view* in Cemu. The phone then shows the
    "GamePad View" window.
  * **DS (melonDS):** the phone shows the bottom screen. Use melonDS's default vertical layout.
  * **3DS (Azahar):** the phone shows the bottom screen. Use the default layout.
* **TV:** mirrors the whole screen, including the WII-UU menu (Off-TV play).
* **Gyro (motion controls):** tap *Gyro* on the phone. Phones only share motion sensors with
  secure pages, so WII-UU also serves `https://<pc>:8443/`. The phone offers this link, and you
  accept its self-signed certificate once.

### Real controller input with DSU

The phone also appears as a DSU ("cemuhook") controller at `127.0.0.1:26760`, one slot per player.
Unlike the keyboard keys, this gives real **analog sticks**, **gyro/accelerometer** and **touch**.
Set it up once in each emulator:

| Emulator | Where to set it up |
|---|---|
| Cemu (Wii U) | Input settings: emulated controller *Wii U GamePad*, API *DSUController*, 127.0.0.1 : 26760. Map the buttons and enable motion. |
| Dolphin (GC/Wii) | Controller settings → Alternate input sources → DSU Client → add 127.0.0.1 : 26760. |
| Azahar (3DS) | Controls → Motion / Touch → *CemuhookUDP*, 127.0.0.1 : 26760. |
| Ryujinx (Switch) | Input → Motion → CemuHook compatible motion, 127.0.0.1 : 26760. |

On Linux the virtual controllers already cover buttons and sticks, so use DSU mainly for motion
and touch. If you use DSU instead of the virtual controller on another OS, set
`system.<id>.keys=false` (for example `system.wiiu.keys=false`) so WII-UU stops typing keys into it. If motion feels inverted in an
emulator, flip axes with `dsu.motionSigns`: accel x y z, then gyro pitch yaw roll, e.g. `+-+ +++`.

Screen streaming and touch use X11/XWayland windows on Linux (install `x11-utils`), user32 on
Windows, and Accessibility / Screen Recording permissions on macOS.

## macOS setup

macOS blocks two things until you allow them. Until then the GamePad screen comes back **black**
and the GamePad buttons don't reach emulators. `install.sh` builds a native `WII-UU.app`
(`~/Applications`, using the JDK's `jpackage`) so these permissions have an app to belong to:

1. Start WII-UU from **~/Applications/WII-UU.app**, not from a terminal.
2. In *System Settings → Privacy & Security*, turn on **WII-UU** under **Screen Recording** and
   **Accessibility**. *Settings (F1) → General → macOS permissions* opens both pages.
3. Restart WII-UU.

If the picture is black, the phone and the TV now say so instead of showing a black screen.

**Dolphin:** there are no virtual controllers on macOS. So while a GameCube or Wii game runs,
WII-UU temporarily gives Dolphin a keyboard mapping that matches exactly what the phone sends:
* **GameCube:** a standard controller in port 1.
* **Wii:** a Wii Remote with Nunchuk. The pointer follows the mouse, which tapping on the phone's
  TV mirror moves.

Your own Dolphin controller settings are backed up and restored when the game ends, or at the
next start if WII-UU was killed. Turn this off with `input.dolphinMapping=off`.

## Updating

* **In the app:** *Settings (F1) → General → Check for updates*. WII-UU also checks once at each
  start and shows a notification when a new version is out.
* **In a terminal:** `wiiuu --upgrade`, or `curl -fsSL https://wiiuu.stoppedwumm.net/get.sh | bash`.

An update downloads the new release, verifies its SHA-256 checksum, and runs its installer.
Settings, ROMs, paired phones and emulators are kept, and WII-UU restarts. To update the
emulators, run `wiiuu-emulators --update`.

## Troubleshooting

* **An emulator doesn't start:**
  * If the configured program isn't installed, WII-UU looks for the emulator under other
    names, in `wiiuu-emulators`, in Flatpak and in `~/Applications/*.AppImage`.
  * If none is found, the notification says so. Dolphin, for example, has no Linux release, so
    install it with `wiiuu-emulators --only dolphin` (a source build).
  * If the emulator crashes at start, the notification shows the last line of
    `~/.wiiuu/logs/<system>.log`.
* **A game doesn't close:** *Close game* (HOME on the phone, or Ctrl+Q) asks the emulator to quit,
  and force-kills it if it's still running after 3 seconds. That includes emulators waiting on a
  "stop emulation?" dialog.
  * **Linux:** the whole process group is stopped, and Flatpak apps with `flatpak kill`.
  * **macOS:** apps started with `open -a App` receive Quit, then their process is stopped by its
    path inside the `.app` bundle.
* **Choppy GamePad screen:** install `ffmpeg`. The phone mentions it when it isn't installed. On
  slow Wi-Fi, lower `stream.maxWidth` or `stream.quality`.

## Settings file

Settings are stored in `~/.wiiuu/config.properties`. You can move this folder with `WIIUU_HOME` or `--home`.
Useful keys:

```properties
roms.base=/home/me/WiiUU/roms
system.wiiu.command="/opt/Cemu/Cemu" -f -g {rom}
system.ps2.romdir=/mnt/games/ps2
system.sms.hidden=true
server.port=8080
server.requireCode=true
server.code=1234            # pairing code (created once and kept; change it to unpair phones)
server.https=true           # secure address for gyro (server.httpsPort=8443)
stream.fps=30               # GamePad screen: stream.maxWidth=854, stream.quality=60, stream.backend=auto|ffmpeg|java
input.keys=auto             # type keys too? auto = only without virtual controllers | on | off
update.check=true           # look for a new version at start
screen.nds.region=0,0.5,1,0.5   # second screen: screen.<id>.window / .aspect / .region
dsu.port=26760              # DSU controller server (dsu.enabled, dsu.motionSigns)
keys.p1.A=X
ui.fullscreen=true
ui.minimizeOnLaunch=true
```

Command line: `wiiuu [--fullscreen|--windowed] [--port N] [--no-server] [--home DIR] [--check-update|--upgrade]`

## Build from source

```sh
./build.sh      # -> build/wiiuu.jar   (JDK 17+)
./package.sh    # -> dist/WII-UU-<version>.zip
java -jar build/wiiuu.jar
```

The code is in `src/wiiuu`:

* `core`: system catalogue, ROM scanner, config and emulator launcher
* `ui`: the Wii U–style Swing menu and the settings dialog
* `net`: the GamePad HTTP server (`com.sun.net.httpserver`) and a small QR encoder
* `input`: routes GamePad input to menu navigation, or to key presses via `java.awt.Robot`

The phone page is `resources/web/pad.html`.
